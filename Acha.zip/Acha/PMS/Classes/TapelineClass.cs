﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMS.Classes
{
    class TapelineClass
    {
        //Getter and Setter
        public int Denier { get; set; }
        public String Color { get; set; }
        public int PP { get; set; }
        public int RC { get; set; }
        public int Calpet { get; set; }
        public int ColorKG { get; set; }
        public object TapeID { get; private set; }
  

        static string myconstring = ConfigurationManager.ConnectionStrings["PMS.Properties.Settings.PMSConnectionString"].ConnectionString;

        public DataTable Select()
        {
            //Database connection

            SqlConnection conn = new SqlConnection(myconstring);
            DataTable dt = new DataTable();
            try
            {
                //Writing SQL query
                string sql = "SELECT * FROM Tapelinetable";
                SqlCommand cmd = new SqlCommand(sql, conn);

                //Creating SQL adapter using cmd
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);

            }
            catch (Exception e)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }


        //Inserting Data into Database
        public bool Insert(TapelineClass c)
        {
            //Creating default return type and setiing its values
            bool isSuccess = false;

            //connect Database
            SqlConnection conn = new SqlConnection(myconstring);
            try
            {
                //create a sql query to insert
                string sql = "INSERT INTO Tapeline (Denier, Color, PP, Calpet, RC, ColorKG) VALUES (@Denier, @Color, @PP, @Calpet, @RC, @ColorKG)";
                //Sql command
                SqlCommand cmd = new SqlCommand(sql, conn);
                //Create parameters
                cmd.Parameters.AddWithValue("@Denier", c.Denier);
                cmd.Parameters.AddWithValue("@Color", c.Color);
                cmd.Parameters.AddWithValue("@PP", c.PP);
                cmd.Parameters.AddWithValue("@Calpet", c.Calpet);
                cmd.Parameters.AddWithValue("@RC", c.RC);
                cmd.Parameters.AddWithValue("@ColorKG", c.ColorKG);


                //Connection opens here

                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                //if qurey runs successfully value of rows > 0

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;

                }

            }
            catch (Exception e)
            {
                MessageBox.Show("OUR Exception " + e);
            }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }

        //Update Method 
        public bool Update(TapelineClass c)
        {
            //Creating default return type and setiing its values
            bool isSuccess = false;

            //connect Database
            SqlConnection conn = new SqlConnection(myconstring);
            try
            {
                //create a sql query to insert
                string sql = "UPDATE Tapeline SET Denier=@Denier, Color=@Color, PP=@PP, Calpet=@Calpet, RC=@RC, ColorKG=@ColorKG WHERE TapeID=@TapeID";

                //Sql command
                SqlCommand cmd = new SqlCommand(sql, conn);
                //Create parameters
                cmd.Parameters.AddWithValue("@Denier", c.Denier);
                cmd.Parameters.AddWithValue("@Color", c.Color);
                cmd.Parameters.AddWithValue("@PP", c.PP);
                cmd.Parameters.AddWithValue("@Calpet", c.Calpet);
                cmd.Parameters.AddWithValue("@RC", c.RC);
                cmd.Parameters.AddWithValue("@ColorKG", c.ColorKG);

                //Connection opens here
                conn.Open();

                int rows = cmd.ExecuteNonQuery();
                //if qurey runs successfully value of rows > 0

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception e) { }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }
        public bool Delete(TapelineClass c)
        {
            bool isSuccess = false;
            //connect Database
            SqlConnection conn = new SqlConnection(myconstring);
            try
            {
                //create a sql query to delete
                string sql = "DELETE from Tapeline WHERE TapeID=@TapeID";

                //Sql command
                SqlCommand cmd = new SqlCommand(sql, conn);
                //Create parameters
                cmd.Parameters.AddWithValue("@TapeID", c.TapeID);
                //Connection opens here
                conn.Open();

                int rows = cmd.ExecuteNonQuery();
                //if qurey runs successfully value of rows > 0

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception e) { }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }

    }
}