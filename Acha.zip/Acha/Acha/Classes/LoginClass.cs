﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Acha.Classes
{
    class LoginClass
    {
        

        static string myconstring = ConfigurationManager.ConnectionStrings["Acha.Properties.Settings.PMSConnectionString"].ConnectionString;



        

    }
}