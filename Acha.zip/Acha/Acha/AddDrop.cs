﻿using Acha.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Acha
{
    public partial class AddDrop : Form
    {
        public AddDrop()
        {
            InitializeComponent();
        }
        TapelineClass c = new TapelineClass();
        private void Mainpage_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable dt = c.Select();
            dgvMainPage.DataSource = dt;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            DataTable dt = c.Select();
            dgvMainPage.DataSource = dt;
        }

        private void btnLoom_Click(object sender, EventArgs e)
        {
            DataTable dt = c.Select();
            dgvMainPage.DataSource = dt;
        }
    }
}
